#! /bin/bash

# first is fst
# second is input

python2.7 ./source/main.py $1 $2